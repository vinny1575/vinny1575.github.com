//
//  MovieItem.m
//  Movies
//
//  Created by Mikel Gonzalez on 10/18/12.
//  Copyright (c) 2012 Mikel Gonzalez. All rights reserved.
//

#import "MovieItem.h"

@implementation MovieItem

@end
