//
//  ViewController.h
//  MD1-Week4
//
//  Created by Alan Gonzalez on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextView *textView;
@property (strong, nonatomic) NSString *text;
@end
