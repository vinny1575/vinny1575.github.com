//
//  SecondViewController.h
//  MD-Week1
//
//  Created by Alan Gonzalez on 5/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface SecondViewController : ViewController
- (IBAction)back:(id)sender;

@end
