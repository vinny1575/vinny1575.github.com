//
//  BussinessObj.m
//  MD-Week3
//
//  Created by Alan Gonzalez on 6/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BussinessObj.h"

@implementation BussinessObj

@synthesize bussinessName, latitude, longitute;
@end
