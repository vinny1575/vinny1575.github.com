//
//  BussinessObj.h
//  MD-Week3
//
//  Created by Alan Gonzalez on 6/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BussinessObj : NSObject
@property(nonatomic, strong) NSString *bussinessName;
@property(nonatomic) double latitude;
@property(nonatomic) double longitute;
@end
