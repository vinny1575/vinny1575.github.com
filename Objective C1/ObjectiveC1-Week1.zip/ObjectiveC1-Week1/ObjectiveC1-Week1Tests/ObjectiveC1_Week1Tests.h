//
//  ObjectiveC1_Week1Tests.h
//  ObjectiveC1-Week1Tests
//
//  Created by Alan Gonzalez on 3/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface ObjectiveC1_Week1Tests : SenTestCase

@end
