//
//  ObjectiveC1_Week1Tests.m
//  ObjectiveC1-Week1Tests
//
//  Created by Alan Gonzalez on 3/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ObjectiveC1_Week1Tests.h"

@implementation ObjectiveC1_Week1Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ObjectiveC1-Week1Tests");
}

@end
